/* David Gershuni, dgershun
 * email: dgershun@andrew.cmu.edu
 *
 * 15-513 Lab 4: Part A
 * Cache Simulator
 * 
 * This program simulates a computer system's cache
 * memory based on parameters supplied by the user's
 * command-line arguments and a memory trace provided
 * in a file.
*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <stdbool.h>
#include "cachelab.h"

#define ADDR_LEN 64

typedef struct cache_request
{	
	unsigned long addr;
	char op[2];
} cache_request_t;

typedef struct cache_set {
	unsigned long num_lines;
	unsigned long* tags;
	bool* valids;
	unsigned long* timestamps;
} cache_set_t;

typedef struct cache {
	cache_set_t* sets; 
	long hits;
	long misses;
	long evicts;
	unsigned long b;
	unsigned long s;
	unsigned long t;
	long shift_tag_r;
	long shift_set_l;
	long shift_set_r;
	long num_sets;
	unsigned long tick;
} cache_t;
 
void print_usage();
cache_t* init_cache(unsigned long s, unsigned long E, unsigned long b);
bool simulate_cache(cache_t* cache, char* trace_fn, bool v);
void handle_cache_request(cache_t* cache, cache_request_t* req, bool v);
void set_cache_line(unsigned long i, unsigned long tag,
										cache_set_t* set, cache_t* cache);
unsigned long find_line_to_evict(cache_set_t* set);
void print_result(bool hit, bool miss, bool evict);

int main(int argc, char *argv[])
{	
	bool success;
	bool v = false;
	unsigned long s = 0;
	unsigned long E = 0;
	unsigned long b = 0;
	char* trace_fn = NULL;
	int opt;

	while ((opt = getopt(argc, argv, "?hvs:E:b:t:")) != -1)
	{
		switch (opt)
		{
			case 'v':
				v = true;
				break;
			case 's':
				s = (unsigned long) atol(optarg);
				break;
			case 'E':
				E = (unsigned long) atol(optarg);
				break;
			case 'b':
				b = (unsigned long) atol(optarg);
				break;
			case 't':
				trace_fn = optarg;
				break;
			case '?':
			case 'h':
			default:
				print_usage();	
				exit(EXIT_FAILURE);
		}		
	}

	if (!s || !E || !b || !trace_fn)
	{
		printf("Error: Missing arguments\n");
		print_usage();
		exit(EXIT_FAILURE);
	}
		
	cache_t* cache = init_cache(s, E, b);
	if (!cache) exit(EXIT_FAILURE);

	success = simulate_cache(cache, trace_fn, v);
	if (success)
		printSummary(cache->hits, cache->misses, cache->evicts);
	
	free(cache);
	return 0;
}

cache_t* init_cache(unsigned long s, unsigned long E, unsigned long b)
{
	cache_t* cache = malloc(sizeof(cache_t));
	
	if (!cache)
	{
		printf("Could not allocate memory for cache\n");
		return NULL;
	}
	cache->tick = 0;
	cache->b = b;
	cache->s = s;
	cache->t = ADDR_LEN - (b + s);
	cache->shift_tag_r = ADDR_LEN - cache->t;
	cache->shift_set_l = cache->t;
	cache->shift_set_r = ADDR_LEN - cache->s;
	cache->num_sets = 1 << s;
	cache->sets = malloc(cache->num_sets * sizeof(cache_set_t));

	if (!cache->sets)
	{
		printf("Could not allocate memory for cache sets\n");
		free(cache);
		return NULL;
	}
	
	// init each cache_set
	cache_set_t* set;
	for (int i=0; i < cache->num_sets; i++)
	{
		set = &(cache->sets[i]);
		set->num_lines = E;
		set->valids	= malloc(E * sizeof(bool));
		set->tags = malloc(E * sizeof(unsigned long));
		set->timestamps = malloc(E * sizeof(unsigned long));
		if (!set->valids || !set->tags || !set->timestamps)
		{
			printf("Could not allocate memory for cache line %d\n", i);
			// free previous cache sets?
			return NULL;
		}
		for (int j=0; j < E; j++)
			set->valids[j] = false;
		for (int j=0; j < E; j++)
			set->timestamps[j] = 0;
	}
	return cache;		
}

bool simulate_cache(cache_t* cache, char* trace_fn, bool v)
{
	FILE* trace_file = fopen(trace_fn, "r");
	if (!trace_file)
	{
		printf("Could not open file\n");
		return false;
	}
	
	cache_request_t req;
	char line[64];
	while (fgets(line, 63, trace_file) != NULL)
	{
		if (sscanf(line, " %1[LS] %lx,%*u", req.op, &req.addr) >= 2)
			handle_cache_request(cache, &req, v);
		else
		{
			printf("Could not match arguments for line: '%s'\n", line);
			break;
		}
	}
	fclose(trace_file);
	return true;
}

void handle_cache_request(cache_t* cache, cache_request_t* req, bool v)
{
	if (v) printf("%s %lx ", req->op, req->addr);		
	bool hit = false;
	bool miss = false;
	bool evict = false;
	cache_set_t* set;
	unsigned long set_index;
	unsigned long tag;
 	long free_line = -1;
	long line = -1;
	// extract fields from address
	set_index	= (req->addr << cache->shift_set_l) >> cache->shift_set_r;
	set = &(cache->sets[set_index]);
	tag = req->addr >> cache->shift_tag_r;

	//printf("Parsed: set=0x%lx, tag=0x%lx\n", set_index, tag);	

	// search for tag in existing cache lines
	for (int i=0; i < set->num_lines; i++)
	{
		if (set->valids[i])
		{
			if (set->tags[i] == tag)
			{
				hit = true;
				line = i;
				break;	
			}
		}
		else
		{
			free_line = i;
		}
	}
	
	if (!hit)
	{
		miss = true;
		if (free_line >= 0)
			line = free_line;
		else
		{
			evict = true;
			line = find_line_to_evict(set);
		}
	}
	
	set_cache_line(line, tag, set, cache);
	
	cache->hits += (long) hit;
	cache->misses	+= (long) miss;
	cache->evicts += (long) evict;

	if (v)
		print_result(hit, miss, evict);
}

unsigned long find_line_to_evict(cache_set_t* set)
{
	unsigned long victim = 0;
	for (int i=1; i < set->num_lines; i++)
	{
		if (set->timestamps[i] < set->timestamps[victim])
			victim = i;	
	}
	return victim;
}

void set_cache_line(unsigned long i, unsigned long tag,
										cache_set_t* set,cache_t* cache)
{
	set->tags[i] = tag;
	set->timestamps[i] = (cache->tick)++;
	set->valids[i] = true;
}

void print_usage()
{
	printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>\n");
	printf("\t-h: Optional help flag that prints usage info\n");
	printf("\t-v: Optional verbose flag that displays trace info\n");
	printf("\t-s <s>: Number of set index bits (S=2^s is the number of sets)\n");
	printf("\t-E <E>: Associativity (number of lines per set)\n");
	printf("\t-b <b>: Number of block bits (B = 2^b is the block size)\n");
	printf("\t-t <tracefile>: Name of the memory trace to replay\n");
	return;
}

void print_result(bool hit, bool miss, bool evict)
{
	hit ? printf(" hit") : printf(" miss");
	if (evict)
	 	printf(" evict");
	printf("\n");
}
