/*
 * David Gershuni, dgershun
 * email: dgershun@andrew.cmu.edu
 *
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(size_t M, size_t N, double A[N][M], double B[M][N], double *tmp);
 * A is the source matrix, B is the destination
 * tmp points to a region of memory able to hold TMPCOUNT (set to 256) doubles as temporaries
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 2KB direct mapped cache with a block size of 64 bytes.
 *
 * Programming restrictions:
 *   No out-of-bounds references are allowed
 *   No alterations may be made to the source array A
 *   Data in tmp can be read or written
 *   This file cannot contain any local or global doubles or arrays of doubles
 *   You may not use unions, casting, global variables, or 
 *     other tricks to hide array data in other forms of local or global memory.
 */ 
#include <stdio.h>
#include <stdbool.h>
#include "cachelab.h"
#include "contracts.h"

/* Forward declarations */
bool is_transpose(size_t M, size_t N, double A[N][M], double B[M][N]);
void trans(size_t M, size_t N, double A[N][M], double B[M][N], double *tmp);
void transpose32x32(size_t M, size_t N,double A[N][M], double B[M][N],
		double *tmp);
int calcOffsetDiagonal(int ii);
int calcOffsetOther(int ii, int jj);
void copyAndTransposeQuadrant(size_t M, size_t N, double A[N][M], 
		double B[M][N], int minI, int minJ, int r, int c);
void copyQuadrantToTemp(size_t M, size_t N, 
				double A[N][M], double B[M][N], double* tmp, int ii, int jj);



#define BLK 8               // number of doubles in a block
#define H_BLK 4             // number of doubles in half a block
#define GRID_WIDTH_32x32  4
#define GRID_HEIGHT_32x32 4
#define GRID_WIDTH_64x64 8
#define GRID_HEIGHT_64x64 8
#define GRID_HEIGHT_65x63 8
#define GRID_WIDTH_65x63 7
#define ROW_LEN_32x32 32
#define ROW_LEN_64x64 64
#define LAST_ROW_65x63 64 // index of last row of a 65x63 matrix

/* This function transposes a 32x32 matrix in a cache-aware way.
 * It uses blocking to generate an 4x4 grid of cache-friendly blocks.
 * Each block is 8 doubles tall and 8 doubles wide.
 * The original matrix is stored in A and the transposed matrix is
 * written to B.
 */
void transpose32x32(size_t M, size_t N,double A[N][M], double B[M][N],
		double *tmp)
{
	int ii, jj, i, j;
	int minI = 0, minJ = 0, maxI = BLK, maxJ=BLK;
	double* tmpStart = tmp + BLK;

	for (ii=0; ii < GRID_HEIGHT_32x32; ii++)
	{
		for (jj=ii; jj < GRID_WIDTH_32x32; jj++) 
		{
			minJ = jj * BLK;
			maxJ = minJ + BLK;
			// if block is on the diagonal
			if (ii == jj)
			{ 
				if (ii > 0)
					tmpStart = tmp;
				// copy mini-grid to temp
				for (i=0; i < BLK; i++)
				{
					for (j=0; j < BLK; j++)
						*(tmpStart + (ROW_LEN_32x32*i) + j) = A[minI+i][minJ+j];
				}
				// copy mini-grid from temp to B
				for (i=0; i < BLK; i++)
				{
					for (j=0; j < BLK; j++)
					{
						B[minJ+j][minI+i] = *(tmpStart + ROW_LEN_32x32*i + j);
					}
				}	
			}
			else
			{
				// non-diagonal blocks, copy symmetrically
				for (i=minI; i < maxI; i++)
					for (j=minJ; j < maxJ; j++)
						B[j][i] = A[i][j];
				
				for (i=minI; i < maxI; i++)
					for (j=minJ; j < maxJ; j++)
						B[i][j] = A[j][i];
			}
		}
		minI += BLK;
		maxI += BLK;
	}
}

/* The function computes a cache-friendly offset into the buffer
 * tmp for transpose64x64 to use when copying a diagonal block with coordinate
 * ii to tmp.
 */
int calcOffsetDiagonal(int ii)
{
	if (ii < 2)
		return BLK*2;
	else
		return 0;
}

/* The function computes a cache-friendly offset into the buffer
 * tmp for transpose64x64 to use when copying a non-diagonal block with
 * coordinates (ii,jj) to tmp.
 */
int calcOffsetOther(int ii, int jj)
{
	if (ii != 0 && jj != 0)
		return 0;
	else if (ii != 1 && jj != 1)
		return BLK;
	else
		return BLK*2;
}

/* This function copies and transposes single quadrant of a block
 * from matrix A directly to matrix B.
 */
void copyAndTransposeQuadrant(size_t M, size_t N, double A[N][M], double B[M][N],
		int minI, int minJ, int r, int c)
{
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < H_BLK; j++)		
		{
			I = minI + (r*H_BLK) + i;
			J = minJ + (c*H_BLK) + j;
			B[J][I] = A[I][J]; 
		}
	}
}

/* This function copies a single quadrant of a block
 * from matrix A to a temporary buffer to avoid conflict misses
 * in the cache.
 */
void copyQuadrantToTemp(size_t M, size_t N, 
		double A[N][M], double B[M][N], double* tmp, int ii, int jj)
{
	double* tmpStart = tmp + calcOffsetOther(ii,jj);
	int minI = ii*BLK;
	int minJ = jj*BLK;
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < H_BLK; j++)		
		{
			I = minI + i;
			J = minJ + H_BLK + j;
			*(tmpStart + (ROW_LEN_64x64 * i) + j) = A[I][J];
		}
	}
}

/* This function copies and transposes a single quadrant of a block
 * from a temporary buffer to B avoid conflict misses
 * in the cache.
 */
void copyQuadrantFromTemp(size_t M, size_t N, 
		double A[N][M], double B[M][N], double* tmp, int ii, int jj)
{
	double* tmpStart = tmp + calcOffsetOther(ii,jj);
	int minI = ii*BLK;
	int minJ = jj*BLK;
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < H_BLK; j++)		
		{
			I = minI + i;
			J = minJ + H_BLK + j;
			B[J][I] = *(tmpStart + (ROW_LEN_64x64 * i) + j);
		}
	}
}

/* This function transposes a 64x64 matrix in a cache-aware way.
 * It uses blocking to generate a 8x8 grid of cache-friendly blocks.
 * Each block is 8 doubles tall and 8 doubles wide. And each block
 * is further divided into 4 quadrants to minimized conflict misses.
 * The original matrix is stored in A and the transposed matrix is
 * written to B.
 */
void transpose64x64(size_t M, size_t N, double A[N][M], double B[M][N],
		double *tmp)
{
	int ii, jj, i, j, r, c;
	int minI, minJ;
	double* tmpStart;
	for (ii=0; ii < BLK; ii++)
	{
		minI = ii * BLK;
		for (jj=0; jj < BLK; jj++) 
		{
			minJ = jj * BLK;
			// if block is on diagonal
			if (ii == jj)	
			{
				tmpStart = tmp + calcOffsetDiagonal(ii);
				// read from A to temp
				for (r = 0; r < 2; r++)
				{
					for (i=0; i < H_BLK; i++)
						for (j=0; j < BLK; j++)	
							*(
								tmpStart + (BLK*r) + (ROW_LEN_64x64 * i) + j
							) = A[minI+i+(H_BLK*r)][minJ+j];
				}
				// write grid 1 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[minJ+j][minI+i] = *(tmpStart + (ROW_LEN_64x64 * i) + j);
				
				// write grid 2 from temp to B
				for (i=0; i < 4; i++)
					for (j=0; j < H_BLK; j++)
						B[H_BLK+minJ+j][minI+i] = *(
							tmpStart + H_BLK + (ROW_LEN_64x64 * i) + j
						);
				// write grid 4 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[H_BLK+minJ+j][minI+H_BLK+i] = *(
							tmpStart + BLK + H_BLK + (ROW_LEN_64x64 * i) + j
						);
				// write grid 3 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[minJ+j][H_BLK+minI+i] = *(
							tmpStart + BLK + (ROW_LEN_64x64 * i) + j
						);
				
			}
			else
			{
				minI = ii*BLK;
				minJ = jj*BLK;
				for (r=0; r < 2; r++)
				{
					for (c=0; c < 2; c++)
					{
						if (r==0 && c==0)
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						else if (r==0 && c==1)
							copyQuadrantToTemp(M,N,A,B,tmp,ii,jj);
						else if (r==1 && c==0)
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						else if (r==1 && c==1)
						{
							copyQuadrantFromTemp(M,N,A,B,tmp,ii,jj);
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						}
					}
				}
			}
		}
	}
}

/* This function copies and traponses an "odd" shaped quadrant of a block
* from matrix A directly to matrix B. 
* Odd quadrants are 4x3 or 3x4.
*/
void copyAndTransposeQuadrantOdd(size_t M, size_t N, double A[N][M],
		double B[M][N], int minI, int minJ, int r, int c)
{
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < 3; j++)		
		{
			I = minI + (r*H_BLK) + i;
			J = minJ + (c*H_BLK) + j;
			B[J][I] = A[I][J]; 
		}
	}
}

/* This function copies an "odd" shaped quadrant of a block
 * from matrix A to a temporary buffer to avoid conflict misses
 * in the cache. Odd quadrants are 4x3 or 3x4.
 */
void copyQuadrantToTempOdd(size_t M, size_t N, 
		double A[N][M], double B[M][N], double* tmp, int ii, int jj)
{
	double* tmpStart = tmp + calcOffsetOther(ii,jj);
	int minI = ii*BLK;
	int minJ = jj*BLK;
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < 3; j++)		
		{
			I = minI + i;
			J = minJ + H_BLK + j;
			*(tmpStart + (ROW_LEN_64x64 * i) + j) = A[I][J];
		}
	}
}

/* This function copies an "odd" shaped quadrant of a block
 * from a temporary buffer to matrix B in order to avoid conflict misses
 * in the cache. Odd quadrants are 4x3 or 3x4.
 */
void copyQuadrantFromTempOdd(size_t M, size_t N, 
		double A[N][M], double B[M][N], double* tmp, int ii, int jj)
{
	double* tmpStart = tmp + calcOffsetOther(ii,jj);
	int minI = ii*BLK;
	int minJ = jj*BLK;
	int I, J;
	for (int i=0; i < H_BLK; i++)
	{
		for (int j=0; j < 3; j++)		
		{
			I = minI + i;
			J = minJ + H_BLK + j;
			B[J][I] = *(tmpStart + (ROW_LEN_64x64 * i) + j);
		}
	}
}


/* This function transposes a 65x63 matrix in a cache-aware way.
 * It follows the strategy of transpose64x64 for the evenly
 * shaped blocks, and it separately handles the odd-shaped blocks.
 * For the 65th row of A, it copies it in units of 8 to B.
 * For last 7-elements in each row of A, it copies them using
 * the "odd quadrant" functions above.
 * The original matrix is stored in A and the transposed matrix is
 * written to B.
 */
void transpose65x63(size_t M, size_t N, double A[N][M], double B[M][N],
		double *tmp)
{
	int ii, jj, i, j, r, c;
	int minI, minJ;
	double* tmpStart;
	for (ii=0; ii < BLK; ii++)
	{
		minI = ii * BLK;
		for (jj=0; jj < 7; jj++) 
		{
			minJ = jj * BLK;
			// if block is on diagonal
			if (ii == jj)	
			{
				tmpStart = tmp + calcOffsetDiagonal(ii);
				// read from A to temp
				for (r = 0; r < 2; r++)
				{
					for (i=0; i < H_BLK; i++)
						for (j=0; j < BLK; j++)	
							*(
								tmpStart + (BLK*r) + (ROW_LEN_64x64 * i) + j
							) = A[minI+i+(H_BLK*r)][minJ+j];
				}
				// write grid 1 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[minJ+j][minI+i] = *(tmpStart + (ROW_LEN_64x64 * i) + j);
				// write grid 2 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[H_BLK+minJ+j][minI+i] = *(
							tmpStart + H_BLK + (ROW_LEN_64x64 * i) + j
						);
				// write grid 4 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[H_BLK+minJ+j][minI+H_BLK+i] = *(
							tmpStart + (BLK+H_BLK) + (ROW_LEN_64x64 * i) + j
						);
				// write grid 3 from temp to B
				for (i=0; i < H_BLK; i++)
					for (j=0; j < H_BLK; j++)
						B[minJ+j][H_BLK+minI+i] = *(
							tmpStart + BLK + (ROW_LEN_64x64 * i) + j
						);
			}
			else
			{
				minI = ii*BLK;
				minJ = jj*BLK;
				for (r=0; r < 2; r++)
				{
					for (c=0; c < 2; c++)
					{
						if (r==0 && c==0)
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						else if (r==0 && c==1)
							copyQuadrantToTemp(M,N,A,B,tmp,ii,jj);
						else if (r==1 && c==0)
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						else if (r==1 && c==1)
						{
							copyQuadrantFromTemp(M,N,A,B,tmp,ii,jj);
							copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
						}
					}
				}
			}
		}
	}

	
	// copy odd right col in 2x2 blocks, except for last
	jj = GRID_WIDTH_65x63;
	minJ = jj*BLK;
	for (ii=0; ii < GRID_HEIGHT_65x63-1; ii++)
	{
		minI = ii*BLK;
		for (r=0; r < 2; r++)
		{
			for (c=0; c < 2; c++)
			{
				if (r==0 && c==0)
					copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
				else if (r==0 && c==1)
					copyQuadrantToTempOdd(M,N,A,B,tmp,ii,jj);
				else if (r==1 && c==0)
					copyAndTransposeQuadrant(M,N,A,B,minI,minJ, r, c);
				else if (r==1 && c==1)
				{
					copyQuadrantFromTempOdd(M,N,A,B,tmp,ii,jj);
					copyAndTransposeQuadrantOdd(M,N,A,B,minI,minJ, r, c);
				}
			}
		}
	}

	// handle last conflict block
	minI = ii*BLK;
	minJ = jj*BLK;

	tmpStart = tmp + calcOffsetDiagonal(ii);
	// read from A to temp
	for (r = 0; r < 2; r++)
	{
		for (i=0; i < H_BLK; i++)
			for (j=0; j < BLK-1; j++)
			{	
				*(
					tmpStart + (BLK*r) + (ROW_LEN_64x64 * i) + j
				) = A[minI+i+(H_BLK*r)][minJ+j];
			}
	}
	// write grid 1 from temp to B
	for (i=0; i < H_BLK; i++)
		for (j=0; j < H_BLK; j++)
			B[minJ+j][minI+i] = *(tmpStart + (ROW_LEN_64x64 * i) + j);
	
	// write grid 2 from temp to B
	for (i=0; i < H_BLK; i++)
		for (j=0; j < H_BLK-1; j++)
			B[H_BLK+minJ+j][minI+i] = *(tmpStart + H_BLK + (ROW_LEN_64x64 * i) + j);
	// write grid 4 from temp to B
	for (i=0; i < H_BLK; i++)
		for (j=0; j < H_BLK-1; j++)
			B[H_BLK+minJ+j][minI+H_BLK+i] = *(
					tmpStart + (BLK+H_BLK) + (ROW_LEN_64x64 * i) + j
			);
	// write grid 3 from temp to B
	for (i=0; i < H_BLK; i++)
		for (j=0; j < H_BLK; j++)
			B[minJ+j][H_BLK+minI+i] = *(tmpStart + BLK + (ROW_LEN_64x64 * i) + j);
	
	// copy bottom 1x63 row
	int I = LAST_ROW_65x63;
	int offset = BLK;
	// copy first 8 numbers to temp to avoid conflicts
	for(jj=0; jj < GRID_WIDTH_65x63; jj++)
	{
		if (jj > BLK)
			offset = 0;
		minJ = jj*BLK;
		for (int j=0; j < BLK; j++)
			*(tmp + offset + j)= A[I][minJ+j];
		for (int j=0; j < BLK; j++)
			B[minJ+j][I] = *(tmp+offset+j);
	}
	// copy last 7 numbers
	minJ = jj*BLK;
	for (int j=0; j < BLK-1; j++)
		*(tmp + j)= A[I][minJ+j];
	for (int j=0; j < BLK-1; j++)
		B[minJ+j][I] = *(tmp+j);

}

/* 
* transpose_submit - This is the solution transpose function that you
*     will be graded on for Part B of the assignment. Do not change
*     the description string "Transpose submission", as the driver
*     searches for that string to identify the transpose function to
*     be graded.
*/
char transpose_submit_desc[] = "Transpose submission";


void transpose_submit(size_t M, size_t N, double A[N][M], double B[M][N], double *tmp)
{
	/*
	 * This is a good place to call your favorite transposition functions
	 * It's OK to choose different functions based on array size, but
	 * your code must be correct for all values of M and N
	 */
	if (M==32 && N == 32)
		transpose32x32(M, N, A, B, tmp);
	else if (M == 64 && N == 64)
		transpose64x64(M,N,A,B,tmp);
	else if (M == 63 && N == 65)
		transpose65x63(M,N,A,B,tmp);
	else 
		trans(M, N, A, B, tmp);
}


/* 
* trans - A simple baseline transpose function, not optimized for the cache.
*/
char trans_desc[] = "Simple row-wise scan transpose";

/*
* The following shows an example of a correct, but cache-inefficient
*   transpose function.  Note the use of macros (defined in
*   contracts.h) that add checking code when the file is compiled in
*   debugging mode.  See the Makefile for instructions on how to do
*   this.
*
*   IMPORTANT: Enabling debugging will significantly reduce your
*   cache performance.  Be sure to disable this checking when you
*   want to measure performance.
*/
void trans(size_t M, size_t N, double A[N][M], double B[M][N], double *tmp)
{
	size_t i, j;

	REQUIRES(M > 0);
	REQUIRES(N > 0);

	for (i = 0; i < N; i++) {
			for (j = 0; j < M; j++) {
					B[j][i] = A[i][j];
			}
	}    

	ENSURES(is_transpose(M, N, A, B));
}

/*
* registerFunctions - This function registers your transpose
*     functions with the driver.  At runtime, the driver will
*     evaluate each of the registered functions and summarize their
*     performance. This is a handy way to experiment with different
*     transpose strategies.
*/
void registerFunctions()
{
	/* Register your solution function */
	registerTransFunction(transpose_submit, transpose_submit_desc); 

	/* Register any additional transpose functions */
//		registerTransFunction(transpose_baseline, transpose_baseline_desc);

}

/* 
* is_transpose - This helper function checks if B is the transpose of
*     A. You can check the correctness of your transpose by calling
*     it before returning from the transpose function.
*/
bool is_transpose(size_t M, size_t N, double A[N][M], double B[M][N])
{
	size_t i, j;

	for (i = 0; i < N; i++) {
			for (j = 0; j < M; ++j) {
					if (A[i][j] != B[j][i]) {
							return false;
					}
			}
	}
	return true;
}

